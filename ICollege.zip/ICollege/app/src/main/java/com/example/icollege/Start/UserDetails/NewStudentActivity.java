package com.example.icollege.Start.UserDetails;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;

import com.example.icollege.R;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;

public class NewStudentActivity extends AppCompatActivity {

    MaterialAutoCompleteTextView letter;
    MaterialAutoCompleteTextView number;
    MaterialButton btn;
    private ArrayAdapter<String> adapterNumber;
    private String[] Numbers = new String[] {"11","12","21","22"};
    private String[] Letters = new String[] {"A","B"};
    private ArrayAdapter<String> adapterLetter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_student);

        letter = (MaterialAutoCompleteTextView) findViewById(R.id.exposedDropdownLetter);
        number = (MaterialAutoCompleteTextView) findViewById(R.id.exposedDropdownNumber);
        btn = (MaterialButton) findViewById(R.id.studentDoneBtn);

        adapterNumber = new ArrayAdapter<>(
                getApplicationContext(), R.layout.dropdawn_item, Numbers);
        adapterLetter = new ArrayAdapter<>(
                getApplicationContext(),R.layout.dropdawn_item, Letters);



    }
}