package com.example.icollege.Main;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.icollege.R;

public class TeacherMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_main);
    }
}