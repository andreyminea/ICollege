package com.example.icollege.Start.UserDetails;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.icollege.R;

public class NewTeacherActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_teacher);
    }
}