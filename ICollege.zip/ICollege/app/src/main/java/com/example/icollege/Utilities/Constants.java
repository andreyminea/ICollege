package com.example.icollege.Utilities;

public class Constants {
    public static String DTag = "DEBUGG";
    public static String UserPrefsName = "UserData";
    public static String PrefsLog = "LogStatus";
    public static String PrefsUserType = "UserData";
    public static String PrefsUserEmail = "Email";
    public static String PrefsUserName = "Name";
    public static String PrefsUserImageUrl = "ImageURL";
}
