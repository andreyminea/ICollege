package com.example.icollege.Start;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.example.icollege.R;
import com.example.icollege.Start.UserDetails.NewStudentActivity;
import com.example.icollege.Start.UserDetails.NewTeacherActivity;
import com.example.icollege.Utilities.Constants;
import com.example.icollege.Utilities.Debug;
import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.common.SignInButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.Arrays;
import java.util.List;

public class LoginActivity extends AppCompatActivity {

    private SignInButton signInButton;
    int RC = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        List<AuthUI.IdpConfig> providers = Arrays.asList(
                new AuthUI.IdpConfig.GoogleBuilder().build()
        );

        Intent intent = AuthUI.getInstance()
                .createSignInIntentBuilder()
                .setAvailableProviders(providers)
                .setLogo(R.drawable.common_google_signin_btn_icon_dark) // replace with logo
                .setTosAndPrivacyPolicyUrls("https://example.com","https://example.com" )
                .setAlwaysShowSignInMethodScreen(true)
                .build();
        startActivityForResult(intent, RC);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == RC)
        {
            if(resultCode==RESULT_OK)
            {
                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                Debug.ToastLong(getApplicationContext(), user.getEmail());
                if(user.getMetadata().getCreationTimestamp() == user.getMetadata().getLastSignInTimestamp())
                {
                    //new user
                   SaveUserDetails(user);
                   Intent intent;
                   if(GetUserType().equals("teacher"))
                   {
                       intent = new Intent(this, NewTeacherActivity.class);
                   }
                   else
                   {
                       intent = new Intent(this, NewStudentActivity.class);
                   }
                   Debug.This(GetUserType());
                   startActivity(intent);
                   this.finish();
                }
                else
                {
                    GetUserDetails(user);
                    Debug.This("Old user");
                    //returning user
                }

            }
            else
            {
                Debug.ToastLong(this, "Sign in failed");
            }
        }
    }

    private String GetUserType()
    {
        SharedPreferences sp = getSharedPreferences(Constants.UserPrefsName, MODE_PRIVATE);
        return sp.getString(Constants.PrefsUserType,"");
    }

    private void GetUserDetails(FirebaseUser user)
    {

    }

    private void SaveUserDetails(FirebaseUser user)
    {
        SharedPreferences sp = getSharedPreferences(Constants.UserPrefsName, MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString(Constants.PrefsUserEmail, user.getEmail());
        editor.putString(Constants.PrefsUserName, user.getDisplayName());
        editor.putString(Constants.PrefsUserImageUrl, user.getPhotoUrl().toString());
        editor.apply();
    }
}